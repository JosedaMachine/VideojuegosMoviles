package com.enginepc;

import com.engine.IFont;
import com.engine.IGraphics;
import com.engine.Image;
import com.engine.SceneBase;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.util.HashMap;

import javax.swing.JFrame;

public class GraphicsPC implements IGraphics {

    private final JFrame window;
    private final Graphics2D graphics2D;
    private final BufferStrategy bufferStrategy;

    HashMap<String, Image> imagesLoaded = new HashMap<>();

    GraphicsPC(JFrame view){
        window = view;
        bufferStrategy = window.getBufferStrategy();
        graphics2D = (Graphics2D) bufferStrategy.getDrawGraphics();
    }

    @Override
    public Image newImage(String name) {
        return new ImagePC(name);
    }

    @Override
    public IFont newFont(String name, int size, boolean isBold) {
        return new FontPC(name , size, isBold);
    }

    @Override
    public void clear(int color) {
        this.graphics2D.setColor(new Color(color, true));
        this.graphics2D.fillRect(0,0, this.getWidth(), this.getHeight());
        this.graphics2D.setPaintMode();
    }

    @Override
    public void translate(int x, int y) {
        //Sí, es así de fácil
        graphics2D.translate(x, y);
    }

    @Override
    public void scale(double x, double y) {
        //Este también es así de fácil
        graphics2D.scale(x, y);
    }

    //TODO: Delete
    @Override
    public void render(SceneBase scene) {
        do {
            do {
                try {
                    clear(0);
                    scene.render(this);
                }
                finally {
                    graphics2D.dispose(); //Elimina el contexto gráfico y libera recursos del sistema realacionado
                }
            } while(bufferStrategy.contentsRestored());
            bufferStrategy.show();
        } while(bufferStrategy.contentsLost());
    }

    @Override
    public void save() {
        //Guardar juego
    }

    @Override
    public void restore() {
        //Restaurar, entiendo
    }

    @Override
    public void drawImage(Image image) {
        drawImage(image, 0, 0);
    }

    @Override
    public void drawImage(Image image, int x, int y) {
        drawImage(image, x, y, 1.0f, 1.0f);
    }

    @Override
    public void drawImage(Image image, int x, int y, float scaleX, float scaleY) {
        int width = (int) (image.getWidth() * scaleX);
        int height = (int) (image.getHeight() * scaleY);
        drawImage(image, x, y, width, height);
    }

    @Override
    public void drawImage(Image image, int x, int y, int width, int height) {
        graphics2D.setPaintMode();
        ImagePC copy = (ImagePC) image;
        graphics2D.drawImage(copy.getImage(), x - width / 2, y - height / 2, width, height, null);
        graphics2D.setPaintMode();
    }

    @Override
    public void setColor(int color) {
        this.graphics2D.setColor(new Color(color, true));
    }

    @Override
    public void setFont(IFont font) {
        FontPC pcFont = (FontPC) font;
        this.graphics2D.setFont(pcFont.currFont);
    }

    @Override
    public void fillRect(int x, int y, int size) {
        fillRect(x, y, size, size);
    }

    @Override
    public void fillRect(int x, int y, int w, int h) {
        this.graphics2D.fillRect(x, y, x + w, y + h);
    }

    @Override
    public void drawRect(int x, int y, int size) {
        drawRect(x, y, size, size);
    }

    @Override
    public void drawRect(int x, int y, int w, int h) {
        this.graphics2D.drawRect(x, y, w, h);
    }

    @Override
    public void drawLine(int x1, int y1, int x2, int y2) {
        this.graphics2D.drawLine(x1, y1, x2, y2);
    }

    @Override
    public void drawText(String text, int x, int y) {

        this.graphics2D.drawString(text, x, y);
    }

    @Override
    public int getWidth() {
        return window.getWidth();
    }

    @Override
    public int getHeight() {
        return window.getHeight();
    }

    @Override
    public int getLogicWidth(int x) {
        return 0;
    }

    @Override
    public int getLogicHeight(int y) {
        return 0;
    }

    @Override
    public int parseRealLogic() {
        return 0;
    }

    @Override
    public void loadImage(Image img, String key) {
        imagesLoaded.put(key, img);
    }

    @Override
    public Image getImage(String key) {
        return imagesLoaded.get(key);
    }

    public BufferStrategy getBufferStrategy(){return bufferStrategy;}
}
