package com.engineandroid;

import com.engine.IColor;

import android.graphics.Color;

public class ColorAndroid extends IColor {
    public static void  Init(){
        IColor.BLACK = Color.BLACK;
        IColor.RED = Color.RED;
        IColor.BLUE = Color.BLUE;
        IColor.WHITE = Color.WHITE;
        IColor.GRAY = Color.GRAY;
    }
}
