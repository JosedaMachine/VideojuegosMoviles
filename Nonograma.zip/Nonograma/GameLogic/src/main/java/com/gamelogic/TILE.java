package com.gamelogic;

public enum TILE {
    CROSS, WRONG, EMPTY, FILL,
}
