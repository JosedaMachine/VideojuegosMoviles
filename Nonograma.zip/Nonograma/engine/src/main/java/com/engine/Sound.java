package com.engine;

public interface Sound {

    public abstract void play();

    public abstract void pause();

    public abstract void resume();
}
