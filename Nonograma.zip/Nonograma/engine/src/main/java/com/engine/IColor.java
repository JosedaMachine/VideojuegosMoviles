package com.engine;

public class IColor {
    public static Object RED = null;
    public static Object BLUE = null;
    public static Object GRAY = null;
    public static Object WHITE = null;
    public static Object BLACK = null;
}
