package com.engine;

//BUSCAR COMO SE MANEJAN LAS IMAGES

public interface Image {

    int getWidth();
    int getHeight();
    boolean isLoaded();
}
