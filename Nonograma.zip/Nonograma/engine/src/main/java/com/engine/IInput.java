package com.engine;

import com.engine.TouchEvent;

import java.util.ArrayList;

public interface IInput {
    ArrayList<TouchEvent> getEventList();
}
