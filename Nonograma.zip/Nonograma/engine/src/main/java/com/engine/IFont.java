package com.engine;

//BUSCAR COMO SE MANEJA LA LA LA LA LA LA LA LA LA LA LA LA LA LA LA LA LA FONT

public interface IFont {
    int getSize();
    boolean isBold();
}
