package com.engine;

//BUSCAR COMO SE MANEJAN LAS IMAGES

public class Image {
    Image(int width, int height) { width = width; height = height; };

    int width, height;

    int getWidth() { return width; };
    int getHeight() { return height; };

}
