package com.engine;

//BUSCAR COMO SE MANEJA INPUT
import java.awt.event.ActionEvent;

public class TouchEvent {
    /* *
    * Clase que representa la información de un toque sobre
    * la pantalla (o evento de ratón). Indicará el tipo (pulsación, liberación,
    * desplazamiento), la posición y el identificador del “dedo” (o botón).
    * */
}
