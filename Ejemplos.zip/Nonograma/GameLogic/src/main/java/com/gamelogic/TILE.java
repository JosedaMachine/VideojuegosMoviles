package com.gamelogic;

public enum TILE {
    EMPTY, FILL, CROSS
}
