package com.gamelogic;

public class NonogramaGame {

}